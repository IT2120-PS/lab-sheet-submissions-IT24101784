
#Excersice 01
#1
setwd("C:\\Users\\anuwi\\Desktop\\ps lab 04")

#import data
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",", stringsAsFactors = FALSE)

attach(branch_data)

str(branch_data)


boxplot(branch_data$Sales, 
        main = "Boxplot of Sales", 
        ylab = "Sales", 
        horizontal = TRUE,
        outline = TRUE)


# Calculate the five-number summary 
five_number_summary <- summary(branch_data$Advertising)
print(five_number_summary)

# Calculate the IQR
IQR_value <- IQR(branch_data$Advertising)
print(paste("IQR for Advertising:", IQR_value))


#5
# find outliers in a numeric vector
find_outliers <- function(x) {
  #  (Q1, Q3)
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  
  # Interquartile Range
  IQR_value <- IQR(x)
  
  # lower and upper bounds 
  lower_bound <- q1 - 1.5 * IQR_value
  upper_bound <- q3 + 1.5 * IQR_value
  
  # outliers
  outliers <- x[x < lower_bound | x > upper_bound]
  
  
  return(outliers)
}

outliers_years <- find_outliers(branch_data$Years)

print(outliers_years)
