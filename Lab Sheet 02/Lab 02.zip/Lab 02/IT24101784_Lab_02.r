#Q2
sum((1:15) %% 3 == 0)

#q3
v <- c(4, 8, 1, 9, 2)
max_index <- 1
for (i in 2:length(v)) {
  if (v[i] > v[max_index]) {
    max_index <- i
  }
}
max_index

#Q4
which.max(v)

