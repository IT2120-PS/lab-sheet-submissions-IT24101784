setwd("C:\\Users\\Anuththara\\OneDrive\\Desktop\\IT24101784")

observed_counts <- c(120, 95, 85, 100)

chisq.test(x = observed_counts)