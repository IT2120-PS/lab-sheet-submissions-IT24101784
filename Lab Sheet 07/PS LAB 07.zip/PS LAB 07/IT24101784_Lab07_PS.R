setwd("C:\\Users\\anuwi\\Desktop\\PS LAB 07")
# Uniform Distribution
# P(10<X<25) = P(X<=25) - P(X<=10)
punif(25, min=0, max=40,lower.tail=TRUE) - punif(10, min=0, max=40,lower.tail=TRUE)

# Exponential Distribution
# P(X<=2)
pexp(2,rate=1/3,lower.tail = TRUE)

# Normal Distribution
# P(X>130) = 1 - P(X<=130)
1 - pnorm(130, mean=100, sd=15, lower.tail=TRUE)
pnorm(130, mean=100, sd=15, lower.tail=FALSE)

# Normal Distribution
# P(X < b)= 0.95
qnorm(0.95, mean=100, sd=15, lower.tail=TRUE)